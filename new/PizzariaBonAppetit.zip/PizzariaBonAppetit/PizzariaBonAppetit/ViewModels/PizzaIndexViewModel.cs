﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PizzariaBonAppetit.Models;

namespace PizzariaBonAppetit.ViewModels
{
    public class PizzaIndexViewModel
    {
        public List<Pizza> Pizzas { get; set; }

    }
}